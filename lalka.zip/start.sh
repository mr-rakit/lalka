#!/bin/sh
while sleep 1;
do
python ./casino_bot.py
done