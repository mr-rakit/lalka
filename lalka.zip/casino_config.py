import telebot
import sqlite3
import random

bot = telebot.TeleBot("5222361352:AAEbUniyug37yzfV1qjKbe6osE5gxoXcass", threaded=True, num_threads=300)

con = sqlite3.connect("dannie_2.db")
cur = con.cursor()

admin_1 = 896786689
admin_2 = 5217779550

admin_chat = -1001654150595
workers_chat = -1001646235118
conclusion_channel = -1001650712432

support_nickname = 'mrrakit'

manual_link = "https://telegra.ph/Primer-11-16-3"
manual_link_2 = "https://telegra.ph/Kak-skryt-referalnuyu-ssylku-02-07"
screens_bot = "screens_help_robot"

bot_name = "Callotrakitabot"
fake_number = "79678349823"
min_summa = 200
min_deposit = 0
people = 10
percent = 20

QIWI_TOKEN = 'ee014d9e0e4b4cf8c2c7964921f5cb40'
QIWI_NUMBER = '79654240409'

# Работа с бд
def get_status(message):
    con = sqlite3.connect("dannie_2.db")
    cur = con.cursor()
    cur.execute(f"""SELECT status FROM users WHERE id = '{message.chat.id}' """)
    status = cur.fetchone()[0]
    return status


def get_balance(message):
    con = sqlite3.connect("dannie_2.db")
    cur = con.cursor()
    cur.execute(f"""SELECT balance FROM users WHERE id = '{message.chat.id}' """)
    balance = cur.fetchone()[0]
    return balance


def get_last_popolnenie(message):
    con = sqlite3.connect("dannie_2.db")
    cur = con.cursor()
    cur.execute(f"""SELECT last_popolnenie FROM users WHERE id = '{message.chat.id}' """)
    last_popolnenie = cur.fetchone()[0]
    return last_popolnenie


def get_referals(message):
    con = sqlite3.connect("dannie_2.db")
    cur = con.cursor()
    cur.execute(f"""SELECT referals FROM users WHERE id = '{message.chat.id}' """)
    referals = cur.fetchone()[0]
    return referals


def get_ref_balance(message):
    con = sqlite3.connect("dannie_2.db")
    cur = con.cursor()
    cur.execute(f"""SELECT ref_balance FROM users WHERE id = '{message.chat.id}' """)
    ref_balance = cur.fetchone()[0]
    return ref_balance


def get_ref_link(message):
    ref_link = f"http://t.me/{bot_name}?start={message.chat.id}"
    return ref_link

def get_random_number(message):
    random_number = random.choice(range (60, 70))
    return random_number


def get_inf_profil(balance, referals, ref_balance, ref_link, random_number):
    inf_profil = f"✅ ЛИЧНЫЙ КАБИНЕТ ✅\n\n" \
                 f"💵 БАЛАНС 💵\n" \
                 f"{balance}₽\n\n\n" \
                 f"👥 Ваши рефералы 👥\n" \
                 f"{referals}\n\n" \
                 f"💰 Ваш реферальный баланс 💰\n" \
                 f"{ref_balance}₽\n\n" \
                 f"👤 Ваша реферальная ссылка 👤\n" \
                 f"{ref_link}\n\n" \
                 f"🎲 Число человек онлайн 🎲\n" \
                 f"{random_number}\n\n"\
                 f"Casino v3 | remastered by MainDay"
    return inf_profil
